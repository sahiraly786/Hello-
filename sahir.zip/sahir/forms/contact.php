<?php

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    echo "Invalid Request!";
    exit;
}

$to = "sahiraly786@gmail.com";

$name    = trim($_POST["name"]);
$email   = trim($_POST["email"]);
$subject = trim($_POST["subject"]);
$message = trim($_POST["message"]);

if (empty($name) || empty($email) || empty($subject) || empty($message)) {
    echo "All fields are required!";
    exit;
}

$headers  = "From: $name <$email>\r\n";
$headers .= "Reply-To: $email\r\n";

$body  = "Name: $name\n";
$body .= "Email: $email\n\n";
$body .= "Message:\n$message\n";

if (mail($to, $subject, $body, $headers)) {
    echo "OK";
} else {
    echo "Mail sending failed!";
}
